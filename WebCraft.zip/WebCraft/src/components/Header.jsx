function Header() {
  return (
    <header className="header">
      <h1>WebCraft</h1>

      <nav>
        <a href="#home">Головна</a>
        <a href="#courses">Курси</a>
        <a href="#about">Про нас</a>
      </nav>
    </header>
  );
}

export default Header;
function CourseCard({ title, description, level, price }) {
  const handleClick = () => {
    alert(`Ви записалися на курс "${title}"!`);
  };

  return (
    <div className="course-card">
      <h2>{title}</h2>

      <p>{description}</p>

      <p><strong>Рівень:</strong> {level}</p>

      <p className="price">{price} грн</p>

      <button onClick={handleClick}>
        Записатися
      </button>
    </div>
  );
}

export default CourseCard;
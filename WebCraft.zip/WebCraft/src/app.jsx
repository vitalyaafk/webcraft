import Header from "./components/Header";
import CourseCard from "./components/CourseCard";
import "./App.css";

function App() {
  const courses = [
    {
      id: 1,
      title: "Frontend Developer",
      description: "Вивчення HTML, CSS, JavaScript та React.",
      level: "Початковий",
      price: 3500
    },
    {
      id: 2,
      title: "Python Developer",
      description: "Основи Python, алгоритми та створення програм.",
      level: "Середній",
      price: 4000
    },
    {
      id: 3,
      title: "Web Design",
      description: "Створення сучасних дизайнів вебсайтів.",
      level: "Початковий",
      price: 3000
    }
  ];

  return (
    <div>
      <Header />

      <main id="home">
        <section className="hero">
          <h1>Навчайся програмувати з WebCraft!</h1>
          <p>
            Обирай IT-курс та відкривай нові можливості
            у світі технологій.
          </p>
        </section>

        <section id="courses" className="courses">
          <h1>Наші курси</h1>

          <div className="course-list">
            {courses.map((course) => (
              <CourseCard
                key={course.id}
                title={course.title}
                description={course.description}
                level={course.level}
                price={course.price}
              />
            ))}
          </div>
        </section>

        <section id="about" className="about">
          <h2>Про WebCraft</h2>
          <p>
            WebCraft — компанія, яка допомагає
            опановувати сучасні IT-технології.
          </p>
        </section>
      </main>

      <footer>
        <p>© 2026 WebCraft. Усі права захищені.</p>
      </footer>
    </div>
  );
}

export default App;